import React, { useState } from 'react';
import './ProfileCard.css';

const BADGE_COLORS = [
  { bg: '#eef0ff', color: '#5a52e0' },
  { bg: '#e8f8f0', color: '#1e7e50' },
  { bg: '#fff4e6', color: '#c17000' },
  { bg: '#fce8f3', color: '#a3256a' },
  { bg: '#e6f7ff', color: '#1566a3' },
];

function ProfileCard({ profile }) {
  const [imgError, setImgError] = useState(false);

  const initials = profile.initials
    || profile.name.split(' ').map((w) => w[0]).join('').slice(0, 2).toUpperCase();

  return (
    <div className="profile-card">
      <div className="card-top">
        <div className="avatar-wrap">
          {profile.imageUrl && !imgError ? (
            <img
              src={profile.imageUrl}
              alt={profile.name}
              className="avatar-img"
              onError={() => setImgError(true)}
            />
          ) : (
            <div className="avatar-fallback">{initials}</div>
          )}
        </div>
        <h2 className="card-name">{profile.name}</h2>
        {profile.role && <p className="card-role">{profile.role}</p>}
      </div>

      <div className="card-divider" />

      <p className="card-bio">{profile.bio}</p>

      {profile.badges && profile.badges.length > 0 && (
        <div className="card-badges">
          {profile.badges.map((badge, i) => {
            const color = BADGE_COLORS[i % BADGE_COLORS.length];
            return (
              <span
                key={i}
                className="badge"
                style={{ background: color.bg, color: color.color }}
              >
                {badge}
              </span>
            );
          })}
        </div>
      )}

      {profile.imageUrl && !imgError && (
        <div className="card-url">
          <span className="url-icon">🔗</span>
          <span className="url-text">{profile.imageUrl}</span>
        </div>
      )}
    </div>
  );
}

export default ProfileCard;
