import React, { useState } from 'react';
import './ProfileForm.css';

function ProfileForm({ onSubmit, loading }) {
  const [form, setForm] = useState({
    name: '',
    role: '',
    bio: '',
    interests: '',
    imageUrl: '',
  });

  const handleChange = (e) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(form);
  };

  return (
    <form className="profile-form" onSubmit={handleSubmit}>
      <div className="form-group">
        <label htmlFor="name">
          Name <span className="required">*</span>
        </label>
        <input
          id="name"
          name="name"
          type="text"
          value={form.name}
          onChange={handleChange}
          placeholder="Alex Johnson"
          required
        />
      </div>

      <div className="form-group">
        <label htmlFor="role">Role / Title</label>
        <input
          id="role"
          name="role"
          type="text"
          value={form.role}
          onChange={handleChange}
          placeholder="Computer Science Student"
        />
      </div>

      <div className="form-group">
        <label htmlFor="bio">
          About You{' '}
          <span className="hint">a few words or a full bio</span>
        </label>
        <textarea
          id="bio"
          name="bio"
          value={form.bio}
          onChange={handleChange}
          placeholder="Passionate about web development and artificial intelligence..."
          rows={4}
        />
      </div>

      <div className="form-group">
        <label htmlFor="interests">
          Interests <span className="hint">comma-separated</span>
        </label>
        <input
          id="interests"
          name="interests"
          type="text"
          value={form.interests}
          onChange={handleChange}
          placeholder="Python, Machine Learning, Open Source"
        />
      </div>

      <div className="form-group">
        <label htmlFor="imageUrl">
          Photo URL <span className="hint">optional</span>
        </label>
        <input
          id="imageUrl"
          name="imageUrl"
          type="url"
          value={form.imageUrl}
          onChange={handleChange}
          placeholder="https://example.com/your-photo.jpg"
        />
      </div>

      <button type="submit" className="btn-submit" disabled={loading}>
        {loading ? (
          <>
            <span className="btn-spinner" /> Generating…
          </>
        ) : (
          '✦ Generate Profile Card'
        )}
      </button>
    </form>
  );
}

export default ProfileForm;
