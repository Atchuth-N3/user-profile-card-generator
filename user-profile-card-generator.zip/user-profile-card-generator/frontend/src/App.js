import React, { useState } from 'react';
import './App.css';
import ProfileForm from './components/ProfileForm';
import ProfileCard from './components/ProfileCard';

function App() {
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (formData) => {
    setLoading(true);
    setError('');
    setProfile(null);

    try {
      const response = await fetch('/api/generate-profile', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Something went wrong');
      }

      setProfile(data);
    } catch (err) {
      setError(err.message || 'Failed to generate profile. Is the backend running?');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="app">
      <header className="app-header">
        <div className="header-inner">
          <div className="header-icon">👤</div>
          <div>
            <h1 className="header-title">Profile Card Generator</h1>
            <p className="header-sub">AI-powered · Fill in your details · Get a polished card</p>
          </div>
        </div>
      </header>

      <main className="app-main">
        <div className="layout">
          <section className="form-section">
            <div className="section-label">Your Info</div>
            <ProfileForm onSubmit={handleSubmit} loading={loading} />
            {error && (
              <div className="error-banner">
                <span className="error-icon">⚠</span>
                {error}
              </div>
            )}
          </section>

          <section className="card-section">
            <div className="section-label">Generated Card</div>
            <div className="card-area">
              {loading && (
                <div className="loading-state">
                  <div className="spinner" />
                  <p>Writing your profile…</p>
                </div>
              )}
              {!loading && !profile && (
                <div className="empty-state">
                  <div className="empty-icon">🪪</div>
                  <p>Your profile card will appear here after you submit the form.</p>
                </div>
              )}
              {!loading && profile && <ProfileCard profile={profile} />}
            </div>
          </section>
        </div>
      </main>
    </div>
  );
}

export default App;
