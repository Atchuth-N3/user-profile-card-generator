from flask import Flask, request, jsonify
from flask_cors import CORS
import anthropic
import os
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)
CORS(app)

client = anthropic.Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))

@app.route("/api/generate-profile", methods=["POST"])
def generate_profile():
    data = request.get_json()

    name = data.get("name", "").strip()
    role = data.get("role", "").strip()
    bio_notes = data.get("bio", "").strip()
    interests = data.get("interests", "").strip()
    image_url = data.get("imageUrl", "").strip()

    if not name:
        return jsonify({"error": "Name is required"}), 400

    prompt = f"""You are a professional profile writer. Given someone's details, produce a polished JSON profile card.

Input:
Name: {name or 'Not provided'}
Role: {role or 'Not provided'}
Bio notes: {bio_notes or 'Not provided'}
Interests: {interests or 'Not provided'}

Return ONLY valid JSON (no markdown, no explanation) with this exact structure:
{{
  "name": "full name as provided",
  "role": "clean role/title (infer if missing)",
  "bio": "2-3 sentence professional bio written in third person, warm and specific, using their notes",
  "badges": ["3-5 short skill or interest tags, max 3 words each"],
  "initials": "2-letter initials from name"
}}"""

    try:
        message = client.messages.create(
            model="claude-sonnet-4-6",
            max_tokens=1000,
            messages=[{"role": "user", "content": prompt}]
        )

        raw = message.content[0].text.strip()
        import json
        profile = json.loads(raw)
        profile["imageUrl"] = image_url

        return jsonify(profile)

    except json.JSONDecodeError:
        return jsonify({"error": "Failed to parse AI response"}), 500
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/health", methods=["GET"])
def health():
    return jsonify({"status": "ok"})


if __name__ == "__main__":
    app.run(debug=True, port=5000)
