from flask import Flask, request, jsonify
from flask_cors import CORS
import anthropic
import os
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)
CORS(app)

client = anthropic.Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))

def mock_generate(name, role, bio_notes, interests):
    # Infer role if missing
    inferred_role = role if role else "Technology Specialist"
    
    # Generate warm, 3rd person bio
    first_name = name.split()[0] if name else "This individual"
    bio = f"{name} is a dedicated professional working as a {inferred_role}."
    if bio_notes:
        bio += f" They are described as: {bio_notes}."
    else:
        bio += " They are passionate about learning new technologies and solving complex problems."
    
    if interests:
        bio += f" {first_name} is particularly interested in {interests} and constantly seeks to expand their knowledge in these areas."
        
    # Generate badges from interests
    badges = []
    if interests:
        badges = [b.strip() for b in interests.split(",") if b.strip()]
    if not badges:
        badges = ["Innovation", "Collaboration", "Technology"]
    badges = badges[:5] # limit to 5
    
    # Initials
    initials = "".join([w[0].upper() for w in name.split() if w])[:2]
    if not initials:
        initials = "P"
        
    return {
        "name": name,
        "role": inferred_role,
        "bio": bio,
        "badges": badges,
        "initials": initials
    }

@app.route("/api/generate-profile", methods=["POST"])
def generate_profile():
    data = request.get_json()

    name = data.get("name", "").strip()
    role = data.get("role", "").strip()
    bio_notes = data.get("bio", "").strip()
    interests = data.get("interests", "").strip()
    image_url = data.get("imageUrl", "").strip()

    if not name:
        return jsonify({"error": "Name is required"}), 400

    prompt = f"""You are a professional profile writer. Given someone's details, produce a polished JSON profile card.

Input:
Name: {name or 'Not provided'}
Role: {role or 'Not provided'}
Bio notes: {bio_notes or 'Not provided'}
Interests: {interests or 'Not provided'}

Return ONLY valid JSON (no markdown, no explanation) with this exact structure:
{{
  "name": "full name as provided",
  "role": "clean role/title (infer if missing)",
  "bio": "2-3 sentence professional bio written in third person, warm and specific, using their notes",
  "badges": ["3-5 short skill or interest tags, max 3 words each"],
  "initials": "2-letter initials from name"
}}"""

    api_key = os.getenv("ANTHROPIC_API_KEY")
    try:
        if not api_key or "your_anthropic_api_key" in api_key or api_key == "":
            raise ValueError("Anthropic API key is not configured or is the default placeholder.")

        message = client.messages.create(
            model="claude-3-5-sonnet-20241022",
            max_tokens=1000,
            messages=[{"role": "user", "content": prompt}]
        )

        raw = message.content[0].text.strip()
        import json
        profile = json.loads(raw)
        profile["imageUrl"] = image_url

        return jsonify(profile)

    except Exception as e:
        print(f"Claude API not available or failed: {e}. Falling back to local mock generator.")
        profile = mock_generate(name, role, bio_notes, interests)
        profile["imageUrl"] = image_url
        return jsonify(profile)


@app.route("/api/health", methods=["GET"])
def health():
    return jsonify({"status": "ok"})


if __name__ == "__main__":
    app.run(debug=True, port=5000)
